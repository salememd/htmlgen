/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* global jUI, app */

(function(){
    app.$(app.lang, {
        'lang': 'en',
        'pm': 'PM',
        'am': 'AM',
        'mnt': 'm',
        'sc': 's',
        'h': 'h',
        'dy': 'd',
        'month1s': 'Jan',
        'month2s': 'Feb',
        'month3s': 'Mar',
        'month4s': 'Apr',
        'month5s': 'May',
        'month6s': 'Jun',
        'month7s': 'Jul',
        'month8s': 'Aug',
        'month9s': 'Sep',
        'month10s': 'Oct',
        'month11s': 'Nov',
        'month12s': 'Dec',
        'month1f': 'January',
        'month2f': 'February',
        'month3f': 'March',
        'month4f': 'April',
        'month5f': 'May',
        'month6f': 'June',
        'month7f': 'July',
        'month8f': 'August',
        'month9f': 'September',
        'month10f': 'October',
        'month11f': 'November',
        'month12f': 'December',
        'wday1s': 'SA',
        'wday2s': 'SU',
        'wday3s': 'MO',
        'wday4s': 'TU',
        'wday5s': 'WE',
        'wday6s': 'TH',
        'wday7s': 'FR',
        'wday1f': 'Saturday',
        'wday2f': 'Sunday',
        'wday3f': 'Monday',
        'wday4f': 'Tusday',
        'wday5f': 'Wednesday',
        'wday6f': 'Thursday',
        'wday7f': 'Friday',
        'cancel': 'Cancel',
        'error': 'Error',
        'warning': 'Warning',
        'info': 'Information',
        'question': 'Question'
    }, true);
})();
